import { createClient } from '@supabase/supabase-js';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL ?? '';
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '';

export const isSupabaseConfigured = Boolean(url && anonKey && url.startsWith('https://'));
export const supabase = createClient(
  isSupabaseConfigured ? url : 'https://example.supabase.co',
  isSupabaseConfigured ? anonKey : 'public-anon-key'
);
